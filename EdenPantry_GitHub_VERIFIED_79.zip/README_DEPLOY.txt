Eden Pantry by RenewPantry — GitHub Pages replacement package
==============================================================

CONTENTS
  index.html          The complete mobile-friendly interactive site
  assets/             Local photographs and four full-resolution social mockups

HOW TO REPLACE THE CURRENT GITHUB PAGES SITE
1. Unzip EdenPantry_GitHub_VERIFIED_79.zip on your computer.
2. Open your existing GitHub repository: https://github.com/a18925736327-droid/eden-pantry
3. In the root of the main branch, replace the existing index.html with the new index.html.
4. Upload the complete assets folder so that the repository contains:
      index.html
      assets/ig_get_the_look.png
      assets/ig_product_prices.png
      assets/ig_build_your_kit.png
      assets/tiktok_pantry_challenge.png
      assets/product_jar.jpg
      assets/product_bags.jpg
      assets/product_wraps.jpg
      assets/product_containers.jpg
      assets/hero_pantry.jpg
5. Click 'Commit changes'. In Settings > Pages, confirm Deploy from a branch > main > /(root).
6. Open https://a18925736327-droid.github.io/eden-pantry/ and refresh after GitHub deploys.

IMPORTANT
- Do not upload the ZIP file alone to the repository expecting GitHub Pages to extract it.
  Unzip it first and upload index.html and the assets folder.
- Product data is deliberately fictional, unified at AUD $24 + $12 + $18 + $25 = $79.
- The jar price allocation is $9 production, $3 packaging/logistics, $8 operations, $4 company profit = $24.
- Click & Collect, delivery, payment, stock, and all storefronts are demonstration-only.
- All assets are local; the website does not depend on external hosting services.

CHINESE QUICK GUIDE / 中文指南
先在电脑解压本压缩包，再到 GitHub 仓库根目录上传 index.html 和整个 assets 文件夹；点击 Commit changes，
在 Settings > Pages 确认 main 分支、/(root) 部署。不要只上传 zip；GitHub 不会自动解压。
新版展示四件商品，价格分别为 $24、$12、$18、$25，合计 $79。所有支付和取货都是演示，不是真实交易。

VERSION CHECK
After upload, search the live webpage for 'Prototype version: 2026-11-01'. If it is absent, the previous index.html is still deployed (or cached).
